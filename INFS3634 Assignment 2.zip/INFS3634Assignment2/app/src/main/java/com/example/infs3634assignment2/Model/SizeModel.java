package com.example.infs3634assignment2.Model;

public class SizeModel {
    private String name;
    private String price;

    public SizeModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
