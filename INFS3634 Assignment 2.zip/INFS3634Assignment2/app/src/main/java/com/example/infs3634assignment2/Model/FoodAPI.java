//package com.example.infs3634assignment2.Model;

//public class FoodAPI {
    //public static String getMostViewedStoriesJsonString() {
      //* return "{
    //    "Foods":{

    //        "01":{
    //            "name":"GINGER Carrot Juice",
                        "image":
                                //          "http://web.archive.org/web/20160531051858if_/http://medifoods.my/images/menu/p1_ginger_pao.jpg",
                                //                  "description":"",
                                //                   "price":"1000"
                                //         },
                                //    "02":{
                                //             "name":"COCONUT ice cream",
                                //           "image":
                                //   "http://web.archive.org/web/20160531062844if_/http://medifoods.my/images/menu/p2_coconut_pao.jpg",
                                //             "description":"",
                                //              "price":"1000"
                                //   },
                                //  "03":{
                                //     "name":"Fried Chicken Wrap",
                                //               "image":
                                //       "http://web.archive.org/web/20160531085743if_/http://medifoods.my/images/menu/p3_red_bean_pao.jpg",
                                //                "description":"",
                                //                "price":"1000"
                                //},
                                // "04":{
                                //  "name":"Coke",
                                //          "image":
                                // "http://web.archive.org/web/20160531103143if_/http://medifoods.my/images/menu/p4_char_siew_pao.jpg",
                        "description":"",
                        "price":"1000"
            },
            "05":{
                "name":"Seafood Burger",
                        "image":
                "http://web.archive.org/web/20160531030052if_/http://medifoods.my/images/menu/p5_chai_pao.jpg",
                        "description":"",
                        "price":"1000"
            },
            "06":{
                "name":"Beef Wrap",
                        "image":
                "http://web.archive.org/web/20160531093214if_/http://medifoods.my/images/menu/d1_onde_onde.jpg",
                        "description":"",
                        "price":"1000"
            },
            "07":{
            "name":"Pork Burger",
                    "image":
            "http://web.archive.org/web/20160531090157if_/http://medifoods.my/images/menu/d2_chai_kuih.jpg",
                    "description":"Pork Burger",
                    "price":"1000",
                    "discount":"0"
        },
            "08":{
                "name":"Chocolate CAKE",
                        "image":
                "http://web.archive.org/web/20160531085724if_/http://medifoods.my/images/menu/d5_yam_cake.jpg",
                        "description":"Chocolate Cake",
                        "price":"1000"
            },
            "09":{
                "name":"RADISH CAKE",
                        "image":
                "http://web.archive.org/web/20160531093137if_/http://medifoods.my/images/menu/d6_radish_cake.jpg",
                        "description":"Chinese Style Burger",
                        "price":"1000"
            },
            "10":{
                "name":"PUMPKIN CAKE",
                        "image":
                "http://web.archive.org/web/20160531024834if_/http://medifoods.my/images/menu/d7_pumpkin_cake.jpg",
                        "description":"",
                        "price":"1000"
            },
            "11":{
                "name":"Wagyu Burger",
                        "image":
                "http://web.archive.org/web/20160531044849if_/http://medifoods.my/images/menu/d8_d9_angku.jpg",
                        "description":"Japanese Style beef burger",
                        "price":"1000"
            },
            "12":{
                "name":"CHICKEN BURGER",
                        "image":
                "http://web.archive.org/web/20160531025101if_/http://medifoods.my/images/menu/d10_fatt_ko.jpg",
                        "description":"Chicken with gluten free bread",
                        "price":"1000"
            },
            "13":{
                "name":"3 LAYER CAKE",
                        "image":
                "http://web.archive.org/web/20160531044203if_/http://medifoods.my/images/menu/d11_three_layer_cake.jpg",
                        "description":"",
                        "price":"1000"
            },
            "14":{
                "name":"THAI STYLE SALAD",
                        "image":
                "http://web.archive.org/web/20160530195807if_/http://medifoods.my/images/menu/a1_thai_style_salad.jpg",
                        "description":"Bamboo fungus in spicy thai style sauce",
                        "price":"1000"
            },
            "15":{
                "name":"BLACK SESAME BURGER",
                        "image":
                "http://web.archive.org/web/20160530140402if_/http://medifoods.my/images/menu/a2_sesame_ball_peanut.jpg",
                        "description":
                "Glutinous bread with black sesame paste filling coated with minced peanuts",
                        "price":"1000"

            }
        }
    }
}

